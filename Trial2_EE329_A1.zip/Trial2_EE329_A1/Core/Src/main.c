// TABLE A1 : LED[Y] Circuit Calcs
/// GPIO Vout: 2.87 V , LED Vf = 1.97, LED i = 1.1mA


#include "main.h"
#include <math.h>       // Needed for pow, sqrt, sin

typedef int var_type;   // Change this to: uint8_t, int32_t, int64_t, float, double

void SystemClock_Config(void);
var_type TestFunction(var_type num);
void GPIO_Setup(void);
void DisplayOnLEDs(int val);
void Delay(void);

int main(void)
{
    HAL_Init();
    SystemClock_Config();
    GPIO_Setup();

    // Count to 15 three times with LED display
    for (int cycle = 0; cycle < 1; cycle++) {
        for (int i = 0; i <= 15; i++) {
            DisplayOnLEDs(i);
            Delay();
        }
    }

    // Set PC0 and PC1 ON, PC2 and PC3 OFF
    GPIOC->ODR &= ~(GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3); // Clear all
    GPIOC->ODR |= (GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3);                            // Set PC0 and PC1

    // Execution timing loop
    var_type result;
    while (1) {
        GPIOC->BSRR = GPIO_PIN_0;         // Start timing: PC0 high
        result = TestFunction(15);        // Call the function
        GPIOC->BRR = GPIO_PIN_0;          // End timing: PC0 low
    }
}

var_type TestFunction(var_type num) {
    var_type test_var;

    GPIOC->BSRR = GPIO_PIN_1;            // Start timing: PC1 high

    // ===== EDIT THIS LINE for different tests (Table A1b) =====
    test_var = num;                      // test_var = num;
    // test_var = num + 1;
    // test_var = num * 3;
    // test_var = num / 3;
    // test_var = num * num;
    // test_var = num % 10;
    // test_var = pow(num, 3);
    // test_var = sqrt(num);
    // test_var = sin(num);

    GPIOC->BRR = GPIO_PIN_1;             // End timing: PC1 low

    return test_var;
}

// Setup GPIO pins PC0–PC3 for output
void GPIO_Setup(void)
{
    RCC->AHB2ENR   |=  (RCC_AHB2ENR_GPIOCEN);
    GPIOC->MODER   &= ~(GPIO_MODER_MODE0 | GPIO_MODER_MODE1 |
                        GPIO_MODER_MODE2 | GPIO_MODER_MODE3);
    GPIOC->MODER   |=  (GPIO_MODER_MODE0_0 | GPIO_MODER_MODE1_0 |
                        GPIO_MODER_MODE2_0 | GPIO_MODER_MODE3_0);
    GPIOC->OTYPER  &= ~(GPIO_OTYPER_OT0 | GPIO_OTYPER_OT1 |
                        GPIO_OTYPER_OT2 | GPIO_OTYPER_OT3);
    GPIOC->PUPDR   &= ~(GPIO_PUPDR_PUPD0 | GPIO_PUPDR_PUPD1 |
                        GPIO_PUPDR_PUPD2 | GPIO_PUPDR_PUPD3);
    GPIOC->OSPEEDR |=  ((3 << GPIO_OSPEEDR_OSPEED0_Pos) |
                        (3 << GPIO_OSPEEDR_OSPEED1_Pos) |
                        (3 << GPIO_OSPEEDR_OSPEED2_Pos) |
                        (3 << GPIO_OSPEEDR_OSPEED3_Pos));

    // Clear all PC0–PC3
    GPIOC->BRR = (GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3);
}

// Display integer value on 4 LEDs using PC0–PC3
void DisplayOnLEDs(int val)
{
    GPIOC->ODR &= ~(GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3); // Clear all
    if (val & 0x01) GPIOC->ODR |= GPIO_PIN_0;
    if (val & 0x02) GPIOC->ODR |= GPIO_PIN_1;
    if (val & 0x04) GPIOC->ODR |= GPIO_PIN_2;
    if (val & 0x08) GPIOC->ODR |= GPIO_PIN_3;
}

// Crude software delay loop
void Delay(void)
{
    for (volatile int i = 0; i < 200000; i++);  // Tune this value as needed
}

// System Clock Configuration (keep unchanged)
void SystemClock_Config(void)
{
    RCC_OscInitTypeDef RCC_OscInitStruct = {0};
    RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

    if (HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1) != HAL_OK)
        Error_Handler();

    RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_MSI;
    RCC_OscInitStruct.MSIState = RCC_MSI_ON;
    RCC_OscInitStruct.MSICalibrationValue = 0;
    RCC_OscInitStruct.MSIClockRange = RCC_MSIRANGE_6;
    RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;

    if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
        Error_Handler();

    RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK |
                                  RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
    RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_MSI;
    RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
    RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
    RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

    if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
        Error_Handler();
}

// Error handler (unchanged)
void Error_Handler(void)
{
    __disable_irq();
    while (1) { }
}
