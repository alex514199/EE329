/* USER CODE BEGIN Header */

/**

  ******************************************************************************

  * @file           : main.c

  * @brief          : Main program body

  ******************************************************************************

  * @attention

  *

  *

  *Created on: Jul 2, 2025

 *      Author: Stella Uribe

 *

 *

  * Copyright (c) 2025 STMicroelectronics.

  * All rights reserved.

  *

  * This software is licensed under terms that can be found in the LICENSE file

  * in the root directory of this software component.

  * If no LICENSE file comes with this software, it is provided AS-IS.

  *

  ******************************************************************************

  */

/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/

#include "main.h"

#include "keypad.h"

//#include "keypad.c" // pasted into main.c for this project

/* Private function prototypes -----------------------------------------------*/

void SystemClock_Config(void);



void Led_Config(void);



int main(void)

{

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */

  HAL_Init();

  /* Configure the system clock */

  SystemClock_Config();



  Keypad_Config();



  Led_Config();















  while (1)

  {

 int key = NO_KEYPRESS;

 int last_key = 0;





  if (Keypad_IsAnyKeyPressed())

      {

          HAL_Delay(50);  // debounce delay



          key = Keypad_WhichKeyIsPressed();



          if (key > 0 && key <= 12)  // Valid keypress

          {

              uint8_t display;



              // Map special keys

              if (key == 10)         // '*'    This will be 10 in binary 1010

                  display = 0xA;

              else if (key == 11)    // '0'    This will turn off all LEDs for 0

                  display = 0x0;

              else if (key == 12)    // '#'    This will be 11 in binary 1011

                  display = 0xB;

              else                   // 1–9

                  display = key;



              // Output 4-bit display value to PC0–PC3 (lower nibble only)

              	 // GPIOC->ODR = (GPIOC->ODR & 0xFFFFFFF0) | (display & 0x0F);

              	  GPIOC->ODR = (GPIOC->ODR & ~0x0F) | (display & 0x0F);

          }

      }

  }



}











void Led_Config(void)



{

RCC->AHB2ENR |= RCC_AHB2ENR_GPIOCEN;  // Enable GPIOC clock



    // Set PC0–PC3 to output mode

    GPIOC->MODER &= ~(GPIO_MODER_MODE0 | GPIO_MODER_MODE1 |

                      GPIO_MODER_MODE2 | GPIO_MODER_MODE3);

    GPIOC->MODER |=  (GPIO_MODER_MODE0_0 | GPIO_MODER_MODE1_0 |

                      GPIO_MODER_MODE2_0 | GPIO_MODER_MODE3_0);



    // Push-pull, no pull-up/pull-down

    GPIOC->OTYPER &= ~(GPIO_OTYPER_OT0 | GPIO_OTYPER_OT1 |

                       GPIO_OTYPER_OT2 | GPIO_OTYPER_OT3);

    GPIOC->PUPDR &= ~(GPIO_PUPDR_PUPD0 | GPIO_PUPDR_PUPD1 |

                      GPIO_PUPDR_PUPD2 | GPIO_PUPDR_PUPD3);



    // High speed (optional)

    GPIOC->OSPEEDR |= ((3 << GPIO_OSPEEDR_OSPEED0_Pos) |

                       (3 << GPIO_OSPEEDR_OSPEED1_Pos) |

                       (3 << GPIO_OSPEEDR_OSPEED2_Pos) |

                       (3 << GPIO_OSPEEDR_OSPEED3_Pos));



}















/**

  * @brief System Clock Configuration

  * @retval None

  */

void SystemClock_Config(void)

{

  RCC_OscInitTypeDef RCC_OscInitStruct = {0};

  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};



  /** Configure the main internal regulator output voltage

  */

  if (HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1) != HAL_OK)

  {

    Error_Handler();

  }



  /** Configure LSE Drive Capability

  */

  HAL_PWR_EnableBkUpAccess();

  __HAL_RCC_LSEDRIVE_CONFIG(RCC_LSEDRIVE_LOW);



  /** Initializes the RCC Oscillators according to the specified parameters

  * in the RCC_OscInitTypeDef structure.

  */

  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_LSE|RCC_OSCILLATORTYPE_MSI;

  RCC_OscInitStruct.LSEState = RCC_LSE_ON;

  RCC_OscInitStruct.MSIState = RCC_MSI_ON;

  RCC_OscInitStruct.MSICalibrationValue = 0;

  RCC_OscInitStruct.MSIClockRange = RCC_MSIRANGE_6;

  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;

  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_MSI;

  RCC_OscInitStruct.PLL.PLLM = 1;

  RCC_OscInitStruct.PLL.PLLN = 71;

  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;

  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;

  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV6;

  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)

  {

    Error_Handler();

  }



  /** Initializes the CPU, AHB and APB buses clocks

  */

  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK

                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;

  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;

  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;

  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;

  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;



  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)

  {

    Error_Handler();

  }



  /** Enable MSI Auto calibration

  */

  HAL_RCCEx_EnableMSIPLLMode();

}



/**

  * @brief LPUART1 Initialization Function

  * @param None

  * @retval None

  */

// --------------------------------------------------- excerpt from keypad.c ---

void Keypad_Config(void)



{

    //Port clock initialize

RCC->AHB2ENR   |=  (RCC_AHB2ENR_GPIOFEN);

    //Column pin initialize - Push Pull, no PU/PD, high speed

COL_PORT->MODER &= ~(GPIO_MODER_MODE12 | GPIO_MODER_MODE13 | GPIO_MODER_MODE14);

COL_PORT->MODER |=  (GPIO_MODER_MODE12_0 | GPIO_MODER_MODE13_0 | GPIO_MODER_MODE14_0);

COL_PORT->OTYPER &= ~(GPIO_OTYPER_OT12 | GPIO_OTYPER_OT13 | GPIO_OTYPER_OT14);

COL_PORT->PUPDR  &= ~(GPIO_PUPDR_PUPD12 | GPIO_PUPDR_PUPD13 | GPIO_PUPDR_PUPD14);

COL_PORT->OSPEEDR |= ((3 << GPIO_OSPEEDR_OSPEED12_Pos) |

                  (3 << GPIO_OSPEEDR_OSPEED13_Pos) |

                  (3 << GPIO_OSPEEDR_OSPEED14_Pos));

//Row pin initialize - Input, pull down

ROW_PORT->MODER &= ~(GPIO_MODER_MODE0 | GPIO_MODER_MODE1 | GPIO_MODER_MODE2 | GPIO_MODER_MODE3);

ROW_PORT->PUPDR &= ~(GPIO_PUPDR_PUPD0 | GPIO_PUPDR_PUPD1 | GPIO_PUPDR_PUPD2 | GPIO_PUPDR_PUPD3);

ROW_PORT->PUPDR |=  (GPIO_PUPDR_PUPD0_1 | GPIO_PUPDR_PUPD1_1 | GPIO_PUPDR_PUPD2_1 | GPIO_PUPDR_PUPD3_1);

}
// -----------------------------------------------------------------------------

int Keypad_IsAnyKeyPressed(void) {

// drive all COLUMNS HI; see if any ROWS are HI

// return true if a key is pressed, false if not

// currently no debounce here - just looking for a key twitch



int TRUE = 1;

int FALSE = 0;





   COL_PORT->BSRR = COL_PINS;         	      // set all columns HI

   for ( uint16_t idx=0; idx<SETTLE; idx++ )   	// let it settle

      ;

   if ((ROW_PORT->IDR & ROW_PINS) != 0 )        // got a keypress!

      return( TRUE );

   else

      return( FALSE );                          // nope.

}



// -----------------------------------------------------------------------------

int Keypad_WhichKeyIsPressed(void) {

// detect and encode a pressed key at {row,col}

// assumes a previous call to Keypad_IsAnyKeyPressed() returned TRUE

// verifies the Keypad_IsAnyKeyPressed() result (no debounce here),

// determines which key is pressed and returns the encoded key ID



   int8_t iRow=0, iCol=0, iKey=0;  // keypad row & col index, key ID result

   int8_t bGotKey = 0;             // bool for keypress, 0 = no press



   COL_PORT->BSRR = COL_PINS;                       	 // set all columns HI



   for ( iRow = 0; iRow < NUM_ROWS; iRow++ ) {      	 // check all ROWS



      if ( ROW_PORT->IDR & (BIT0 << iRow) ) {      	 // keypress in iRow!!



         COL_PORT->BRR = ( COL_PINS );            	 // set all cols LO



         for ( iCol = 0; iCol < NUM_COLS; iCol++ ) {   // 1 col at a time



            COL_PORT->BSRR = ( GPIO_PIN_12 << (iCol) );     // set this col HI

            												// FOUND THE BUG it should be working now

            												//Originally GPIO_PIN_12 was BIT0, and iCol+4, however it assumed I was using PF5, 6, and 7



            if ( ROW_PORT->IDR & (BIT0 << iRow) ) {    // keypress in iCol!!



               bGotKey = 1;

               break;                                  // exit for iCol loop

            }



         }



         if ( bGotKey )

            break;

      }

   }

   //	encode {iRow,iCol} into LED word : row 1-3 : numeric, ‘1’-’9’

   //	                                   row 4   : ‘*’=10, ‘0’=15, ‘#’=12

   //                                    no press: send NO_KEYPRESS

   if ( bGotKey ) {

      iKey = ( iRow * NUM_COLS ) + iCol + 1;  // handle numeric keys ...


/// FIX THIS TO FIX ZERO
 	if ( iKey == KEY_ZERO )                 //    works for ‘*’, ‘#’ too

         iKey = CODE_ZERO;

 	return( iKey );                         // return encoded keypress

   }

   return( NO_KEYPRESS );                     // unable to verify keypress

}


















/* USER CODE BEGIN 4 */



/* USER CODE END 4 */



/**

  * @brief  This function is executed in case of error occurrence.

  * @retval None

  */

void Error_Handler(void)

{

  /* USER CODE BEGIN Error_Handler_Debug */

  /* User can add his own implementation to report the HAL error return state */

  __disable_irq();

  while (1)

  {

  }

  /* USER CODE END Error_Handler_Debug */

}



#ifdef  USE_FULL_ASSERT

/**

  * @brief  Reports the name of the source file and the source line number

  *         where the assert_param error has occurred.

  * @param  file: pointer to the source file name

  * @param  line: assert_param error line source number

  * @retval None

  */

void assert_failed(uint8_t *file, uint32_t line)

{

  /* USER CODE BEGIN 6 */

  /* User can add his own implementation to report the file name and line number,

     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* USER CODE END 6 */

}

#endif /* USE_FULL_ASSERT */
