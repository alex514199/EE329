Core/Src/switch.o: ../Core/Src/switch.c ../Core/Inc/switch.h
../Core/Inc/switch.h:
