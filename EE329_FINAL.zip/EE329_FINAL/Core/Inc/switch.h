#ifndef BUTTON_CONTROL_H
#define BUTTON_CONTROL_H

#ifdef __cplusplus
extern "C" {
#endif

/* --------------------------------------------------------------------------
   WIRING (NUCLEO-L4A6ZG defaults in this file)
   --------------------------------------------------------------------------
   BUTTON (3-wire module):
     NUCLEO PC13  <--  Button Module OUT
     NUCLEO 3V3   -->  Button Module VCC         (ensure module is 3.3V logic!)
     NUCLEO GND   <--  Button Module GND

   TEST LED (using Nucleo on-board LED, PA5):
     NUCLEO PA5   -->  LED anode (on-board)      (external LED would need a resistor)
     NUCLEO GND   <--  LED cathode (on-board)

   (If you later drive a pump/relay, typical mapping is:
     NUCLEO PB0   -->  Relay/MOSFET driver IN
     NUCLEO GND   <--  Relay/MOSFET driver GND
     Battery +    -->  Relay/MOSFET power path to pump
     Battery -    <--  NUCLEO GND (common ground!)
   )
   -------------------------------------------------------------------------- */

#include "main.h"
#include <stdint.h>

/* ======================= CONFIG (EDIT IF NEEDED) ======================= */
/* Button is a module driving PC13 (push-pull). Most are active-low (pressed = 0). */
#define BTN_GPIO_PORT           GPIOC
#define BTN_GPIO_PIN            GPIO_PIN_13
#define BUTTON_ACTIVE_LOW       1           /* 1 = pressed reads LOW; 0 = pressed reads HIGH */
#define BUTTON_DEBOUNCE_MS      50u

/* LED on PA5 (Nucleo green LED). Active-high. */
#define LED_GPIO_PORT           GPIOA
#define LED_GPIO_PIN            GPIO_PIN_5
#define LED_ACTIVE_HIGH         1           /* 1 = write HIGH to turn ON */

/* LED pulse after a press */
#define LED_PULSE_MS            500u        /* 0.5 s */

/* GPIO clocks (match your ports above) */
#define ENABLE_BTN_GPIO_CLK()   __HAL_RCC_GPIOC_CLK_ENABLE()
#define ENABLE_LED_GPIO_CLK()   __HAL_RCC_GPIOA_CLK_ENABLE()

/* ========================== PUBLIC API ================================= */

/* Call once at startup. Configures PC13 (input, no-pull) and PA5 (output). */
void ButtonControl_Init(void);

/* Call every 1–5 ms in the main loop. Handles debounce & LED timeout. */
void ButtonControl_Task(void);

/* Senses a valid (debounced) button press, sends a message, turns on LED.
   You typically DO NOT call this yourself; ButtonControl_Task() calls it
   when it detects a press edge. Exposed for clarity/testing. */
void Button_Press(void);

/* Turns the LED ON for 500 ms (LED_PULSE_MS). */
void LED_on(void);

/* Optional accessors (0 = OFF/Released, 1 = ON/Pressed) */
uint8_t Button_IsPressed(void);
uint8_t LED_IsOn(void);

/* Weak hook: override in your project to send logs via UART/USB/etc. */
void __attribute__((weak)) Button_SendMessageToBoard(const char* msg);

#ifdef __cplusplus
}
#endif
#endif /* BUTTON_CONTROL_H */
