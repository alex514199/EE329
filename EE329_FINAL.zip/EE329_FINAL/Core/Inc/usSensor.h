// Ultra Sonic Sensor
//
// LAYOUT
// vcc -> 3.3v
// gnd -> GND
// RX(3) -> PB4
// TX(4) -> PB5
#ifndef ULTRASONIC_PWM_H
#define ULTRASONIC_PWM_H

#ifdef __cplusplus
extern "C" {
#endif

#include "main.h"
#include <stdint.h>

/* ========= BOARD WIRING =========
   Ultrasonic sensor:
   - TRIG input  -> PB4 (output from MCU)
   - PWM output  -> PB5 (TIM3_CH2 input capture)
*/

/* === Trigger pin (PB4 as GPIO) === */
#define US_TRIG_GPIO_PORT        GPIOB
#define US_TRIG_GPIO_PIN         GPIO_PIN_4

/* === PWM output pin (PB5, TIM3_CH2) === */
#define US_PWM_TIM_HANDLE        htim3        // extern TIM_HandleTypeDef htim3;
#define US_PWM_TIM_INSTANCE      TIM3
#define US_PWM_CHANNEL           TIM_CHANNEL_2
#define US_PWM_GPIO_PORT         GPIOB
#define US_PWM_GPIO_PIN          GPIO_PIN_5

/* Timer recommended config (in CubeMX):
   - TIM3 clock = 80 MHz
   - Prescaler = 79  (tick = 1 MHz = 1 µs per tick)
   - Configure CH2 as PWM Input (TI2)
   - Enable TIM3 IRQ
*/

/* Sensor conversion constants — EDIT per datasheet */
#define US_USE_DUTY_BASED        0   // 1 = duty-cycle mapping, 0 = pulse-width mapping

#if US_USE_DUTY_BASED
#define MAX_MM_FROM_DUTY         400.0f
#else
#define WIDTH_OFFSET_US          0.0f
#define US_PER_MM                5.0f
#endif

/* API */
typedef enum { UPWM_OK = 0, UPWM_NOLOCK } upwm_status_t;

void UPWM_Init(TIM_HandleTypeDef* htim);
upwm_status_t UPWM_ReadRaw(uint32_t* high_us, uint32_t* period_us);
float UPWM_ToDistance_Duty(uint32_t high_us, uint32_t period_us);
float UPWM_ToDistance_Width(uint32_t high_us);

#ifdef __cplusplus
}
#endif

#endif /* ULTRASONIC_PWM_H */
