// 	INIT //
// UltraSonic Sensor
// vcc   -> 3.3v
// gnd   -> GND
// RX(3) -> PB4
// TX(4) -> PB5

/// LCD
// Vcc	 -> 3.3V
// GND   -> GND
// RS    -> PA4
// RW    -> PA5
// E     -> PA6
// D4 	 -> PA0
// D5    -> PA1
// D6    -> PA2
// D7    -> PA3
/// Motor
// Vcc    -> ?? V
// gnd    -> GND
// pwmOUT -> PB1

/// Switch Button
// out	 -> PC13
// Vcc	 -> 3.3V
// GND   -> GND

// Relay


/* USER CODE BEGIN Header */
/**
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32l4xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
