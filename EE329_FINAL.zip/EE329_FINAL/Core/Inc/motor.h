#include <stdbool.h>
#include <stdint.h>

#if PUMP_HAS_CH2
#ifndef PUMP2_EN_GPIO_PORT
#define PUMP2_EN_GPIO_PORT       GPIOB
#endif
#ifndef PUMP2_EN_GPIO_PIN
#define PUMP2_EN_GPIO_PIN        GPIO_PIN_1
#endif
#endif

/* Timed burst helper (non-blocking): default burst length in ms */
#ifndef PUMP_DEFAULT_BURST_MS
#define PUMP_DEFAULT_BURST_MS    300u
#endif

/* ===================== PUBLIC API ===================== */
void  Pump_Init(void);

/* Immediate control */
void  Pump_On(void);
void  Pump_Off(void);
uint8_t Pump_IsOn(void);   // returns 1 = ON, 0 = OFF


#if PUMP_HAS_CH2
void  Pump2_On(void);
void  Pump2_Off(void);
uint8_t Pump_IsOn(void);   // returns 1 = ON, 0 = OFF
#endif

/* Timed burst on the main pump enable (non-blocking; call Pump_Task() in main loop) */
void  Pump_StartBurst(uint32_t ms);
void  Pump_Task(void);

#ifdef __cplusplus
}
#endif


