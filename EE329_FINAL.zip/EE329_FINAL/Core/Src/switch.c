/*
 * switch.c
 *
 *  Created on: Aug 25, 2025
 *      Author: alex5
 */
#include "switch.h"


/* Internal state (uint8 flags; no <stdbool.h>) */
static uint8_t s_btnStable   = 1;  /* normalized: 1=released, 0=pressed */
static uint8_t s_lastRaw     = 1;  /* last instantaneous read (normalized) */
static uint32_t s_lastChange = 0;  /* last time the raw state changed */

static uint8_t s_ledIsOn     = 0;  /* 0=OFF, 1=ON */
static uint32_t s_ledOffAt   = 0;  /* timestamp (ms) when LED should turn off */

/* --------- helpers to map active-high/active-low to actual pin writes ---------- */
static inline void LED_Write(uint8_t on)
{
    s_ledIsOn = (on ? 1 : 0);

    GPIO_PinState level;
    if (LED_ACTIVE_HIGH) {
        level = (on ? GPIO_PIN_SET : GPIO_PIN_RESET);
    } else {
        level = (on ? GPIO_PIN_RESET : GPIO_PIN_SET);
    }
    HAL_GPIO_WritePin(LED_GPIO_PORT, LED_GPIO_PIN, level);
}

/* Weak hook: user can override this to transmit over UART, USB CDC, etc. */
void __attribute__((weak)) Button_SendMessageToBoard(const char* msg)
{
    /* Default: do nothing.
       Example override (in another file):
         void Button_SendMessageToBoard(const char* msg) {
             HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), 50);
         }
    */
    (void)msg;
}

/* ========================== PUBLIC API =============================== */

void ButtonControl_Init(void)
{
    /* Enable GPIO clocks for the chosen ports */
    ENABLE_BTN_GPIO_CLK();
    ENABLE_LED_GPIO_CLK();

    /* Configure BUTTON PC13 as input.
       For a 3-wire button module that drives OUT as push-pull: use NO PULL.
       If your module is open-drain, use PULL-UP or PULL-DOWN accordingly. */
    GPIO_InitTypeDef gi = {0};
    gi.Pin   = BTN_GPIO_PIN;
    gi.Mode  = GPIO_MODE_INPUT;      /* polling + debounce (no EXTI required) */
    gi.Pull  = GPIO_NOPULL;          /* module drives the line */
    gi.Speed = GPIO_SPEED_FREQ_LOW;  /* speed irrelevant for input */
    HAL_GPIO_Init(BTN_GPIO_PORT, &gi);

    /* Configure LED pin as push-pull output, start OFF */
    gi.Pin   = LED_GPIO_PIN;
    gi.Mode  = GPIO_MODE_OUTPUT_PP;
    gi.Pull  = GPIO_NOPULL;
    gi.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(LED_GPIO_PORT, &gi);
    LED_Write(0);

    /* Initialize debounce state from current pin level */
    uint8_t raw = (HAL_GPIO_ReadPin(BTN_GPIO_PORT, BTN_GPIO_PIN) == GPIO_PIN_SET) ? 1 : 0;

    /* Normalize so 0=pressed, 1=released for internal state */
    if (BUTTON_ACTIVE_LOW) {
        /* pressed = LOW (0), released = HIGH (1) → already correct */
    } else {
        /* pressed = HIGH (1) → invert so pressed becomes 0 */
        raw = raw ? 0 : 1;
    }

    s_lastRaw   = raw;
    s_btnStable = raw;
    s_lastChange = HAL_GetTick();
    s_ledOffAt   = 0;
}

void ButtonControl_Task(void)
{
    uint32_t now = HAL_GetTick();

    /* ---- 1) Read and normalize button raw state ---- */
    uint8_t raw = (HAL_GPIO_ReadPin(BTN_GPIO_PORT, BTN_GPIO_PIN) == GPIO_PIN_SET) ? 1 : 0;

    if (BUTTON_ACTIVE_LOW) {
        /* pressed = 0 (LOW) already — nothing to do */
    } else {
        /* pressed = HIGH → invert so pressed maps to 0 */
        raw = raw ? 0 : 1;
    }

    /* ---- 2) Debounce ---- */
    if (raw != s_lastRaw) {
        s_lastRaw = raw;
        s_lastChange = now;
        /* wait until stable for BUTTON_DEBOUNCE_MS before accepting */
    } else {
        if ((now - s_lastChange) >= BUTTON_DEBOUNCE_MS) {
            /* stable long enough: accept change */
            if (s_btnStable != raw) {
                s_btnStable = raw;

                /* Edge detection: pressed edge is when stable state becomes 0 */
                if (s_btnStable == 0) {
                    Button_Press();   /* do the thing on press */
                }
                /* release edge ignored (does not cancel LED pulse) */
            }
        }
    }

    /* ---- 3) LED auto-off after LED_PULSE_MS ---- */
    if ((s_ledIsOn == 1) && (now >= s_ledOffAt)) {
        LED_Write(0);
    }
}

/* Called when a valid, debounced press is detected.
   Sends a message to the board, and turns LED ON for 0.5 s. */
void Button_Press(void)
{
    Button_SendMessageToBoard("BUTTON: pressed\r\n");
    LED_on();
}

/* Turns the LED on for LED_PULSE_MS (default 500 ms).
   If called again while LED is on, it extends the on-time. */
void LED_on(void)
{
    LED_Write(1);
    s_ledOffAt = HAL_GetTick() + LED_PULSE_MS;
}

/* Optional helpers */
uint8_t Button_IsPressed(void) { return (s_btnStable == 0) ? 1 : 0; }
uint8_t LED_IsOn(void)         { return s_ledIsOn; }
