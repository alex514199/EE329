/*
 * motor.c
 *
 *  Created on: Aug 25, 2025
 *      Author: alex5
 */
#include "motor.h"

uint8_t Pump_IsOn(void) {
    return pumpIsOn;
}
