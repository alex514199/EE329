/*
 * led.h
 *
 *  Created on: Jul 16, 2025
 *      Author: alex5
 */

#ifndef INC_LED_H_
#define INC_LED_H_

void Led_Config(void);
void LED_On(void);
void LED_Off(void);

#endif /* INC_LED_H_ */
