/*
 * keypad.h
 *
 *  Created on: Jul 2, 2025
 *      Author: Stella Uribe/Alex Maldonado
 */
#ifndef SRC_KEYPAD_H_

#define SRC_KEYPAD_H_

#include "stm32l4xx_hal.h"

#define COL_PORT GPIOF           // I'm using PF0-3, and PF12-14

#define ROW_PORT GPIOF

#define COL_PINS (GPIO_PIN_12 | GPIO_PIN_13 | GPIO_PIN_14)

#define ROW_PINS (GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3)

#define NUM_ROWS 4
#define NUM_COLS 3

// --- Bit shifting macro ---

#define BIT0 0x0001

#define SETTLE 1900

#define NO_KEYPRESS 0x0

//When '0' (key 14) is pressed, turn LEDS off
#define KEY_ZERO 14
#define CODE_ZERO 0x0

void Keypad_Config(void);

int Keypad_IsAnyKeyPressed(void);

int Keypad_WhichKeyIsPressed(void);

#endif /* SRC_KEYPAD_H_ */
