// lcd.h
#ifndef __LCD_H
#define __LCD_H

#include "stm32l4xx_hal.h"
#include <stdint.h>

/* Control pins */
#define LCD_RS_GPIO_PORT GPIOA
#define LCD_RS_PIN       GPIO_PIN_4
#define LCD_RW_GPIO_PORT GPIOA
#define LCD_RW_PIN       GPIO_PIN_5
#define LCD_E_GPIO_PORT  GPIOA
#define LCD_E_PIN        GPIO_PIN_6

/* Data pins (4-bit mode) */
#define LCD_D4_GPIO_PORT GPIOA
#define LCD_D4_PIN       GPIO_PIN_0
#define LCD_D5_GPIO_PORT GPIOA
#define LCD_D5_PIN       GPIO_PIN_1
#define LCD_D6_GPIO_PORT GPIOA
#define LCD_D6_PIN       GPIO_PIN_2
#define LCD_D7_GPIO_PORT GPIOA
#define LCD_D7_PIN       GPIO_PIN_3

/* Public API */
void    LCD_Init(void);
void    LCD_Clear(void);
void    LCD_Send_Command(uint8_t cmd);
void    LCD_Send_Data(uint8_t data);
void    LCD_Send_String(const char *str);
void    LCD_Set_Cursor(uint8_t column, uint8_t row);
void	LCD_Display_Time(uint8_t mm, uint8_t ss);
#endif /* __LCD_H */
