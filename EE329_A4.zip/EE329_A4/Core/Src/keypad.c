/*
 * keypad.c
 *
 *  Created on: Jul 16, 2025
 *      Author: alex5
 */
#include "stm32l4xx_hal.h"   // for GPIO_TypeDef, RCC, HAL_Delay, etc.
#include "keypad.h"          // for COL_PORT, ROW_PORT, COL_PINS, ROW_PINS, NUM_ROWS, BIT0, SETTLE, NO_KEYPRESS, KEY_ZERO, etc.


void Keypad_Config(void)



{

    //Port clock initialize

RCC->AHB2ENR   |=  (RCC_AHB2ENR_GPIOFEN);

    //Column pin initialize - Push Pull, no PU/PD, high speed

COL_PORT->MODER &= ~(GPIO_MODER_MODE12 | GPIO_MODER_MODE13 | GPIO_MODER_MODE14);

COL_PORT->MODER |=  (GPIO_MODER_MODE12_0 | GPIO_MODER_MODE13_0 | GPIO_MODER_MODE14_0);

COL_PORT->OTYPER &= ~(GPIO_OTYPER_OT12 | GPIO_OTYPER_OT13 | GPIO_OTYPER_OT14);

COL_PORT->PUPDR  &= ~(GPIO_PUPDR_PUPD12 | GPIO_PUPDR_PUPD13 | GPIO_PUPDR_PUPD14);

COL_PORT->OSPEEDR |= ((3 << GPIO_OSPEEDR_OSPEED12_Pos) |

                  (3 << GPIO_OSPEEDR_OSPEED13_Pos) |

                  (3 << GPIO_OSPEEDR_OSPEED14_Pos));

//Row pin initialize - Input, pull down

ROW_PORT->MODER &= ~(GPIO_MODER_MODE0 | GPIO_MODER_MODE1 | GPIO_MODER_MODE2 | GPIO_MODER_MODE3);

ROW_PORT->PUPDR &= ~(GPIO_PUPDR_PUPD0 | GPIO_PUPDR_PUPD1 | GPIO_PUPDR_PUPD2 | GPIO_PUPDR_PUPD3);

ROW_PORT->PUPDR |=  (GPIO_PUPDR_PUPD0_1 | GPIO_PUPDR_PUPD1_1 | GPIO_PUPDR_PUPD2_1 | GPIO_PUPDR_PUPD3_1);

}
// -----------------------------------------------------------------------------

int Keypad_IsAnyKeyPressed(void) {

// drive all COLUMNS HI; see if any ROWS are HI

// return true if a key is pressed, false if not

// currently no debounce here - just looking for a key twitch



int TRUE = 1;

int FALSE = 0;





   COL_PORT->BSRR = COL_PINS;         	      // set all columns HI

   for ( uint16_t idx=0; idx<SETTLE; idx++ )   	// let it settle

      ;

   if ((ROW_PORT->IDR & ROW_PINS) != 0 )        // got a keypress!

      return( TRUE );

   else

      return( FALSE );                          // nope.

}



// -----------------------------------------------------------------------------

int Keypad_WhichKeyIsPressed(void) {

// detect and encode a pressed key at {row,col}

// assumes a previous call to Keypad_IsAnyKeyPressed() returned TRUE

// verifies the Keypad_IsAnyKeyPressed() result (no debounce here),

// determines which key is pressed and returns the encoded key ID



   int8_t iRow=0, iCol=0, iKey=0;  // keypad row & col index, key ID result

   int8_t bGotKey = 0;             // bool for keypress, 0 = no press



   COL_PORT->BSRR = COL_PINS;                       	 // set all columns HI



   for ( iRow = 0; iRow < NUM_ROWS; iRow++ ) {      	 // check all ROWS



      if ( ROW_PORT->IDR & (BIT0 << iRow) ) {      	 // keypress in iRow!!



         COL_PORT->BRR = ( COL_PINS );            	 // set all cols LO



         for ( iCol = 0; iCol < NUM_COLS; iCol++ ) {   // 1 col at a time



            COL_PORT->BSRR = ( GPIO_PIN_12 << (iCol) );     // set this col HI

            												// FOUND THE BUG it should be working now

            												//Originally GPIO_PIN_12 was BIT0, and iCol+4, however it assumed I was using PF5, 6, and 7



            if ( ROW_PORT->IDR & (BIT0 << iRow) ) {    // keypress in iCol!!



               bGotKey = 1;

               break;                                  // exit for iCol loop

            }



         }



         if ( bGotKey )

            break;

      }

   }

   //	encode {iRow,iCol} into LED word : row 1-3 : numeric, ‘1’-’9’

   //	                                   row 4   : ‘*’=10, ‘0’=15, ‘#’=12

   //                                    no press: send NO_KEYPRESS

   if ( bGotKey ) {

      iKey = ( iRow * NUM_COLS ) + iCol + 1;  // handle numeric keys ...


/// FIX THIS TO FIX ZERO
 	if ( iKey == KEY_ZERO )                 //    works for ‘*’, ‘#’ too

         iKey = CODE_ZERO;

 	return( iKey );                         // return encoded keypress

   }

   return( NO_KEYPRESS );                     // unable to verify keypress
}
