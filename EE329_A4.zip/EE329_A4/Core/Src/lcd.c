// lcd.c
#include "lcd.h"
#include <string.h>
#include <stdio.h>
/* Pulse the E line to latch in D4–D7 */
static void LCD_Enable_Pulse(void)
{
    HAL_GPIO_WritePin(LCD_E_GPIO_PORT, LCD_E_PIN, GPIO_PIN_SET);
    HAL_Delay(1);
    HAL_GPIO_WritePin(LCD_E_GPIO_PORT, LCD_E_PIN, GPIO_PIN_RESET);
    HAL_Delay(1);
}

/* Put 4 bits on D4–D7 and pulse */
static void LCD_Send_4Bits(uint8_t nibble)
{
    HAL_GPIO_WritePin(LCD_D4_GPIO_PORT, LCD_D4_PIN, (nibble >> 0) & 0x01 ? GPIO_PIN_SET : GPIO_PIN_RESET);
    HAL_GPIO_WritePin(LCD_D5_GPIO_PORT, LCD_D5_PIN, (nibble >> 1) & 0x01 ? GPIO_PIN_SET : GPIO_PIN_RESET);
    HAL_GPIO_WritePin(LCD_D6_GPIO_PORT, LCD_D6_PIN, (nibble >> 2) & 0x01 ? GPIO_PIN_SET : GPIO_PIN_RESET);
    HAL_GPIO_WritePin(LCD_D7_GPIO_PORT, LCD_D7_PIN, (nibble >> 3) & 0x01 ? GPIO_PIN_SET : GPIO_PIN_RESET);
    LCD_Enable_Pulse();
}

/* Wrapper to send a full byte, RS = 0 for cmd, 1 for data */
static void LCD_Send(uint8_t byte, GPIO_PinState rs)
{
    HAL_GPIO_WritePin(LCD_RS_GPIO_PORT, LCD_RS_PIN, rs);
    HAL_GPIO_WritePin(LCD_RW_GPIO_PORT, LCD_RW_PIN, GPIO_PIN_RESET);
    LCD_Send_4Bits(byte >> 4);
    LCD_Send_4Bits(byte & 0x0F);
}

void LCD_Send_Command(uint8_t cmd)
{
    LCD_Send(cmd, GPIO_PIN_RESET);
}

void LCD_Send_Data(uint8_t data)
{
    LCD_Send(data, GPIO_PIN_SET);
}

void LCD_Clear(void)
{
    LCD_Send_Command(0x01);
    HAL_Delay(2);
}

void LCD_Send_String(const char *str)
{
    while (*str)
        LCD_Send_Data((uint8_t)*str++);
}

void LCD_Set_Cursor(uint8_t column, uint8_t row)
{
    uint8_t address;

    // Clamp inputs (optional)
    if (column > 15) column = 15;
    if (row > 1)     row = 1;

    // DDRAM mapping for 2×16:
    // row 0 starts at 0x00, row 1 at 0x40
    address = (row == 0) ? (0x00 + column)
                         : (0x40 + column);

    // The “Set DDRAM Address” command is 0x80 | addr
    LCD_Send_Command(0x80 | address);
}

void LCD_Init(void)
{
    /* 1) Enable GPIOA clock */
    __HAL_RCC_GPIOA_CLK_ENABLE();

    /* 2) Configure all pins as push-pull outputs */
    GPIO_InitTypeDef gpio = {
        .Pin   = LCD_D4_PIN|LCD_D5_PIN|LCD_D6_PIN|LCD_D7_PIN
               |LCD_RS_PIN|LCD_RW_PIN|LCD_E_PIN,
        .Mode  = GPIO_MODE_OUTPUT_PP,
        .Pull  = GPIO_NOPULL,
        .Speed = GPIO_SPEED_FREQ_LOW
    };
    HAL_GPIO_Init(GPIOA, &gpio);

    /* 3) Wait for LCD to power up */
    HAL_Delay(60);

    /* 4) 4-bit init sequence */
    LCD_Send_4Bits(0x03);
    HAL_Delay(5);
    LCD_Send_4Bits(0x03);
    HAL_Delay(2);
    LCD_Send_4Bits(0x03);
    HAL_Delay(1);
    LCD_Send_4Bits(0x02);

    /* 5) Function set: 2 lines, 5x8 font */
    LCD_Send_Command(0x28);
    /* Display ON, cursor OFF, blink OFF */
    LCD_Send_Command(0x0C);
    /* Clear display */
    LCD_Clear();
    /* Entry mode: increment, no shift */
    LCD_Send_Command(0x06);
}
void LCD_Display_Time(uint8_t mm, uint8_t ss)
{
	char buffer[6];
	snprintf(buffer,sizeof(buffer),"%02u:%02u", mm, ss);
	LCD_Set_Cursor(0,1);
	LCD_Send_String(buffer);
}
