/*
 * led.c
 *
 *  Created on: Jul 16, 2025
 *      Author: alex5
 */

#include "led.h"
#include "stm32l4xx_hal.h"

// bitmask for PC0, PC1, PC2, PC3, PC4
#define LED_PINS  ( GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 \
                  | GPIO_PIN_3)

void Led_Config(void)
{
    // 1) Enable GPIOC clock
    __HAL_RCC_GPIOC_CLK_ENABLE();

    // 2) Configure PC0–PC3 as push-pull outputs, no pull, low speed
    GPIO_InitTypeDef gpio = {
      .Pin   = LED_PINS,
      .Mode  = GPIO_MODE_OUTPUT_PP,
      .Pull  = GPIO_NOPULL,
      .Speed = GPIO_SPEED_FREQ_LOW
    };
    HAL_GPIO_Init(GPIOC, &gpio);
}

void LED_On(void)
{
    // Drive all LEDs high
    HAL_GPIO_WritePin(GPIOC, LED_PINS, GPIO_PIN_SET);
}

void LED_Off(void)
{
    // Turn them all off
    HAL_GPIO_WritePin(GPIOC, LED_PINS, GPIO_PIN_RESET);
}
