/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Simplified User Reaction Timer (millisecond resolution)
  ******************************************************************************
  * Created on: Jul 2, 2025
  *      Author: Stella Uribe, Alejandro Maldonado, Simplified Version
  ******************************************************************************
  */

#include "main.h"
#include "led.h"
#include "lcd.h"
#include "keypad.h"
#include <stdlib.h>    // for rand(), srand()
#include <stdio.h>     // for snprintf()

typedef enum { IDLE, WAIT_RESPONSE, SHOW_RESULT } ReactionState;

int main(void)
{
    HAL_Init();
    SystemClock_Config();
    Keypad_Config();
    Led_Config();                // config PC0 LED
    LCD_Init();
    srand((unsigned)HAL_GetTick());
    ReactionState state = IDLE;
    uint32_t random_delay_ms = 0;
    uint32_t start_tick = 0;
    uint32_t reaction_time = 0;
    char buf[17];

    while (1)
    {
        // 1)At the top to always check for 10 000 ms timeout, before reading any key:
        if (state == WAIT_RESPONSE && (HAL_GetTick() - start_tick) >= 10000U) {
            HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_RESET);
            state = IDLE;

        }

        // 2) Draw the idle screen whenever we’re back in IDLE
        if (state == IDLE) {
            LCD_Set_Cursor(0,0);
            LCD_Send_String("EE 329 REACTION TIME");
            LCD_Set_Cursor(0,1);
            LCD_Send_String("PUSH # TO START   ");
        }

        // 3) '#' press  once per loop
        if (Keypad_WhichKeyIsPressed() == 12) {
            HAL_Delay(20);
            while (Keypad_IsAnyKeyPressed()) HAL_Delay(5);

            if (state == IDLE) {
                //random delay & LED
                state = WAIT_RESPONSE;
                random_delay_ms = (rand() % 2501) + 500;
                LCD_Set_Cursor(0,1);
                LCD_Send_String("Get Ready...    ");
                HAL_Delay(random_delay_ms);
                HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_SET);
                start_tick = HAL_GetTick();
            }
            else if (state == WAIT_RESPONSE) {
                // measure, display result, move to SHOW_RESULT
                reaction_time = HAL_GetTick() - start_tick;
                HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_RESET);
                if (reaction_time < 1000) {
                    snprintf(buf, sizeof(buf), "Time: 0:MMM s", reaction_time);
                } else {
                    snprintf(buf, sizeof(buf), "Time: %lu:%03lu s",
                             reaction_time/1000, reaction_time%1000);
                }
                LCD_Set_Cursor(0,1);
                LCD_Send_String(buf);
                state = SHOW_RESULT;
            }
            else if (state == SHOW_RESULT) {
                // final '#' resets to IDLE
                state = IDLE;
            }
        }
    }
}
// Clock Settings for STM32
void SystemClock_Config(void)
{
    RCC_OscInitTypeDef osc = {0};
    RCC_ClkInitTypeDef clk = {0};

    osc.OscillatorType = RCC_OSCILLATORTYPE_MSI;
    osc.MSIState = RCC_MSI_ON;
    osc.MSICalibrationValue = RCC_MSICALIBRATION_DEFAULT;
    osc.MSIClockRange = RCC_MSIRANGE_6;      // e.g. 4 MHz
    osc.PLL.PLLState = RCC_PLL_ON;
    osc.PLL.PLLSource = RCC_PLLSOURCE_MSI;
    osc.PLL.PLLM = 1;
    osc.PLL.PLLN = 40;
    osc.PLL.PLLR = RCC_PLLR_DIV2;
    if (HAL_RCC_OscConfig(&osc) != HAL_OK) Error_Handler();

    clk.ClockType = RCC_CLOCKTYPE_SYSCLK|RCC_CLOCKTYPE_HCLK
                  |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
    clk.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
    clk.AHBCLKDivider = RCC_SYSCLK_DIV1;
    clk.APB1CLKDivider = RCC_HCLK_DIV1;
    clk.APB2CLKDivider = RCC_HCLK_DIV1;
    if (HAL_RCC_ClockConfig(&clk, FLASH_LATENCY_4) != HAL_OK) Error_Handler();
    // Restore SysTick for 1 kHz using the new HCLK
    HAL_SYSTICK_Config(HAL_RCC_GetHCLKFreq()/1000U);
    HAL_SYSTICK_CLKSourceConfig(SYSTICK_CLKSOURCE_HCLK);
}
void Error_Handler(void)
{
  __disable_irq();
  while (1) {}
}
